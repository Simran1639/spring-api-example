package com.company.springboot.customer.dao;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.company.springboot.customer.dto.CustomerDTO;



@Component
public class CustomerDAO {
	
	private static final Logger log = LoggerFactory.getLogger(CustomerDAO.class);
	
	@Autowired
	JdbcTemplate jdbctemplate;
	
	@Autowired
	CustomerDTO customerdto;
	
//	public CustomerDTO createCustomer(CustomerDTO customerDto) {
//        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbctemplate)
//                .withProcedureName("customer");
//
//        SqlParameterSource in = new MapSqlParameterSource()
//                .addValue("param1", customerDto.getId())
//                .addValue("param2", customerDto.getName())
//                .addValue("param3", customerDto.getDateOfBirth())
//                .addValue("param4", customerDto.getAmount())
//                .addValue("param5", customerDto.getActive());
//        return ;
//	}

	public Map<String, Object> createCustomer(CustomerDTO customerDto) {
	Map<String, Object> resMap = new HashMap<>();
	try {
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbctemplate)
				.withProcedureName("customer");
		SqlParameterSource in = new MapSqlParameterSource()
				.addValue("param1", customerDto.getId())
                .addValue("param2", customerDto.getName())
                .addValue("param3", customerDto.getDateOfBirth())
                .addValue("param4", customerDto.getAmount())
                .addValue("param5", customerDto.getActive());
		
		return simpleJdbcCall.execute(in);
		
	}catch (Exception e) {
		log.error("error", e);
		return resMap;
	}
				
}
	public Map<String, Object> getAllCustomerDetailsByName(String name) {
		Map<String, Object> resMap = new HashMap<>();
		try {
        SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbctemplate)
                .withProcedureName("customer")
                .returningResultSet("customerdto", BeanPropertyRowMapper.newInstance(CustomerDTO.class));

        SqlParameterSource in = new MapSqlParameterSource().addValue("param2", name);

        resMap = simpleJdbcCall.execute(in);
		}
        catch (Exception e) {
			log.error("error in getting customer details ", e);
		}
		return resMap;
	}
	
	public int deleteCustomerDetails(CustomerDTO customerDTO) {
        int status = 0;
        try {
            String sql = "DELETE FROM customerdto WHERE id=?";
            status = jdbctemplate.update(sql, customerDTO.getId());
        } catch (Exception e) {
            log.error("error in deleteCustomerDetails -> ", e);
        }
        return status;
    }
	
}




