package com.company.springboot.customer.dto;

//import java.math.BigDecimal;
//import java.time.LocalDate;
//import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDTO {
	
	@Id
	private int id;
    @JsonProperty private String name;
    @JsonProperty private int dateOfBirth;
    @JsonProperty private int amount;
    @JsonProperty private int active;
    

}
