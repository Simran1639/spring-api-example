package com.company.springboot.customer.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.company.springboot.customer.dto.CustomerDTO;
import com.company.springboot.customer.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	public CustomerService customerservice;
	
	@PostMapping("/addCustomer")
	public String insertCustomer(@RequestBody CustomerDTO customerDTO) {
		return customerservice.createCustomer(customerDTO);
	}
	
//	@PostMapping("/addCustomer")
//	public Map<String, Object> insertCustomer(@RequestBody CustomerDTO customerDTO) {
//		return customerservice.createCustomer(customerDTO);
//		}
//	
	
	@GetMapping("/customer/{name}")
    public Map<String, Object> getAllCustomerDetailsByName(@PathVariable String name) {
        return customerservice.getAllCustomerDetails(name);
    }

}
