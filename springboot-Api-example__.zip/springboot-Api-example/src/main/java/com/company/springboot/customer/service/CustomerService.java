package com.company.springboot.customer.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.company.springboot.customer.dao.CustomerDAO;
import com.company.springboot.customer.dto.CustomerDTO;

//import com.mysql.cj.log.Log;

import org.springframework.util.StringUtils;;

@Service
public class CustomerService {
	
	private static final Logger log = LoggerFactory.getLogger(CustomerService.class);
	
	@Autowired
	CustomerDAO customerdao;
	
	@Autowired
	CustomerDTO customerdto;
	
	public String createCustomer(CustomerDTO customerDTO) {
        if (StringUtils.isEmpty(customerDTO.getName()) && customerDTO.getId()==0 && customerDTO.getDateOfBirth()==0
        		&& customerDTO.getAmount()==0 && customerDTO.getActive()==0) {
            return "Error----- Missing required fields";
        }
        try {
        	customerdao.createCustomer(customerDTO);
            return "Success";
        } catch (Exception e) {
            return "Error------- Failed to insert customer record";
        }
    }
	
//	public Map<String, Object> createCustomer(CustomerDTO customerDTO) {
//		Map<String, Object> response = new HashMap<>();
//        if (StringUtils.isEmpty(customerDTO.getName()) && customerDTO.getId()==0 && customerDTO.getDateOfBirth()==0
//        		&& customerDTO.getAmount()==0 && customerDTO.getActive()==0) {
//             response.put("missing required field", response);
//        }
//        try {
//        	customerdao.createCustomer(customerDTO);
//        } catch (Exception e) {
//            return response;
//        }
//        return response;
//	}
//    
	
	public Map<String, Object> getAllCustomerDetails(String name) {
        Map<String, Object> response = new HashMap<>();
     
        try {
        if (StringUtils.hasText(name)) {
            response = customerdao.getAllCustomerDetailsByName(name);
            log.info("response {}",response);
        } else {
            response.put("error", "Name is not filled");
        }
        }catch (Exception e) {
        	//log.error("error in getting customer details -> ",e);
            response.put("error",e);
        }
        return response;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
	
//	public Map<String, Object> getAllCustomerDetails(int id) {
//        Map<String, Object> response = new HashMap<>();
//     
//        try {
//        if (customerdto.getId()!=0) {
//            response = customerdao.getAllCustomerDetailsByName(name);
//            log.info("response {}",response);
//        } else {
//            response.put("error", "Name is not filled");
//        }
//        }catch (Exception e) {
//        	//log.error("error in getting customer details -> ",e);
//            response.put("error",e);
//        }
//        return response;
//	}
//}
	
	


