package com.company.springboot.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootApiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
